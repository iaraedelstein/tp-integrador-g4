# tp-integrador-g4

Tp Integrador Grupo 4

## Consigna

## Endpoints API

## Integrantes

- Iara Edelstein
- Jorge Rivera
- Guillermo Dorfman
- Mauro Lopez
- Joel Nicolás Sartori
- Lihuen
